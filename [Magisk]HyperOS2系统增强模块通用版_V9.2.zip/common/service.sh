#!/system/bin/sh
MODDIR=${0%/*}
install_config="$MODDIR/rely/config.conf"
shizuku_dir="$MODDIR/rely/shizuku_starter"

function get_prop() {
  cat $install_config | grep -v '^#' | grep "^$1=" | cut -f2 -d '='
}

# set_value value path
function set_value() {
  if [[ -f $2 ]]; then
    chmod 644 $2 2>/dev/null
    echo $1 > $2
  fi
}

function wait_sys_boot_completed()
{
    while true
    do
        sleep 10
        boot_completed=$(getprop sys.boot_completed)
        if [[ "$boot_completed" == "1" ]];then
            return
        fi
    done
}
#wait_sys_boot_completed

if [ $(get_prop log) = "TRUE" ]; then
    rm -rf /data/vivono.log
    echo 等待运行 >> /data/vivono.log
fi
while [ "$(/system/bin/app_process -Djava.class.path=$MODDIR/rely/isKeyguardLocked.dex /system/bin com.rosan.shell.ActiviteJava)" == "true" ];
do
sleep 1
done
$shizuku_dir
#/data/local/tmp/shizuku_starter
#dmode=$(get_prop mode)

MiuiHome=$(get_prop MiuiHome)
MIUISystemUIPlugin=$(get_prop MIUISystemUIPlugin)
OverLay=$(get_prop OverLay)

if [ "$MiuiHome" = "true" ]; then
#    pm install -r -d $MODDIR//base.apk
#    cp $MODDIR//system/product/priv-app/MiuiHome/MiuiHome.apk /data/local/tmp
    pm install -r -d $MODDIR//system/product/priv-app/MiuiHome/MiuiHome.apk
fi

if [ "$MIUISystemUIPlugin" = "true" ]; then
    pm install -r -d $MODDIR//system/product/app/MIUISystemUIPlugin.apk
fi

if [ "$OverLay" = "true" ]; then
    pm install -r -d $MODDIR//system/product/overlay/MonetMiuiHome.apk
    pm install -r -d $MODDIR//system/product/overlay/MonetSettings.apk
    pm install -r -d $MODDIR//system/product/overlay/MonetXiaomiAccount.apk
    pm install -r -d $MODDIR//system/product/overlay/MonetMiuiSystemUIPlugin.apk
    pm install -r -d $MODDIR//system/product/overlay/MonetMiuiSystemUI.apk
    pm install -r -d $MODDIR//system/product/overlay/MonetMiSettings.apk
    pm install -r -d $MODDIR//system/product/overlay/MonetInCallUI.apk
    pm install -r -d $MODDIR//system/product/overlay/Monet-FlashhSettingsOverlay.apk
    pm install -r -d $MODDIR//system/product/overlay/Monet-com.coolapk.market.apk
    pm install -r -d $MODDIR//system/product/overlay/Monet-com.salt.music.apk
    pm install -r -d $MODDIR//system/product/overlay/Monet-idm.internet.download.manager.apk
    pm install -r -d $MODDIR//system/product/overlay/Monet-idm.internet.download.manager.plus.apk
    pm install -r -d $MODDIR//system/product/overlay/Monet-top.yukonga.miBlur.apk
    pm install -r -d $MODDIR//system/product/overlay/MonetAiAsstVision.apk
    pm install -r -d $MODDIR//system/product/overlay/MonetAppVault.apk
    pm install -r -d $MODDIR//system/product/overlay/MonetAuthManager.apk
    pm install -r -d $MODDIR//system/product/overlay/MonetBackup.apk
    pm install -r -d $MODDIR//system/product/overlay/MonetBluetooth.apk
    pm install -r -d $MODDIR//system/product/overlay/MonetCalculator.apk
    pm install -r -d $MODDIR//system/product/overlay/MonetCloudService.apk
    pm install -r -d $MODDIR//system/product/overlay/MonetContacts.apk
    pm install -r -d $MODDIR//system/product/overlay/MonetDeskClock.apk
    pm install -r -d $MODDIR//system/product/overlay/MonetDownloadProvider.apk
    pm install -r -d $MODDIR//system/product/overlay/MonetDownloadProviderUi.apk
    pm install -r -d $MODDIR//system/product/overlay/MonetEmail.apk
    pm install -r -d $MODDIR//system/product/overlay/MonetFileExplorer.apk
    pm install -r -d $MODDIR//system/product/overlay/MonetFindDevice.apk
    pm install -r -d $MODDIR//system/product/overlay/MonetMiShare.apk
    pm install -r -d $MODDIR//system/product/overlay/MonetMiCallAssistant.apk
    pm install -r -d $MODDIR//system/product/overlay/MonetMiDrive.apk
    pm install -r -d $MODDIR//system/product/overlay/MonetMiGalleryLockscreen.apk
    pm install -r -d $MODDIR//system/product/overlay/MonetMiInputSettings.apk
    pm install -r -d $MODDIR//system/product/overlay/MonetMiIntentResolver.apk
    pm install -r -d $MODDIR//system/product/overlay/MonetMiLinkService.apk
    pm install -r -d $MODDIR//system/product/overlay/MonetMiService.apk
    pm install -r -d $MODDIR//system/product/overlay/MonetMiSound.apk
    pm install -r -d $MODDIR//system/product/overlay/MonetMiuiAccessibility.apk
    pm install -r -d $MODDIR//system/product/overlay/MonetMiuiAudioMonitor.apk
    pm install -r -d $MODDIR//system/product/overlay/MonetMiuiBluetooth.apk
    pm install -r -d $MODDIR//system/product/overlay/MonetMiuiBugReport.apk
    pm install -r -d $MODDIR//system/product/overlay/MonetMiuiCamera.apk
    pm install -r -d $MODDIR//system/product/overlay/MonetMiuiCompass.apk
    pm install -r -d $MODDIR//system/product/overlay/MonetMiuiContentCatcher.apk
    pm install -r -d $MODDIR//system/product/overlay/MonetMiuiCore.apk
    pm install -r -d $MODDIR//system/product/overlay/MonetMiuiExtraPhoto.apk
    pm install -r -d $MODDIR//system/product/overlay/MonetMiuiFramework.apk
    pm install -r -d $MODDIR//system/product/overlay/MonetMiuiFreeformService.apk
    pm install -r -d $MODDIR//system/product/overlay/MonetMiuiFrequentPhrase.apk
    pm install -r -d $MODDIR//system/product/overlay/MonetMiuiGallery.apk
    pm install -r -d $MODDIR//system/product/overlay/MonetMiuiScanner.apk
    pm install -r -d $MODDIR//system/product/overlay/MonetMiuiScreenshot.apk
    pm install -r -d $MODDIR//system/product/overlay/MonetMiuiVideoGlobal.apk
    pm install -r -d $MODDIR//system/product/overlay/MonetMiuiYellowPage.apk
    pm install -r -d $MODDIR//system/product/overlay/MonetMms.apk
    pm install -r -d $MODDIR//system/product/overlay/MonetNotificationCenter.apk
    pm install -r -d $MODDIR//system/product/overlay/MonetPackageInstaller.apk
    pm install -r -d $MODDIR//system/product/overlay/MonetPowerKeeper.apk
    pm install -r -d $MODDIR//system/product/overlay/MonetScreenRecorder.apk
    pm install -r -d $MODDIR//system/product/overlay/MonetSecurityCenter.apk
    pm install -r -d $MODDIR//system/product/overlay/MonetSoundRecorder.apk
    pm install -r -d $MODDIR//system/product/overlay/MonetSecurityCoreAdd.apk
    pm install -r -d $MODDIR//system/product/overlay/MonetSystemAppsUpdater.apk
    pm install -r -d $MODDIR//system/product/overlay/MonetTelecom.apk
    pm install -r -d $MODDIR//system/product/overlay/MonetTeleService.apk
    pm install -r -d $MODDIR//system/product/overlay/MonetThemeManager.apk
    pm install -r -d $MODDIR//system/product/overlay/MonetTouchAssistant.apk
    pm install -r -d $MODDIR//system/product/overlay/MonetUpdater.apk
    pm install -r -d $MODDIR//system/product/overlay/MonetWeather.apk
    pm install -r -d $MODDIR//system/product/overlay/SettingsResourceOverlay.apk
fi

# 小白条跟随应用移动
sleep 2 && cmd overlay fabricate --target android --name NavbarAttach android:bool/config_attachNavBarToAppDuringTransition 0x12 1
cmd overlay enable com.android.shell:NavbarAttach

# 防止主题恢复
chmod 731 /data/system/theme
