✔ 中文
刷前必备：
• 核心破解
• Magisk自动救砖模块
• TWRP

修复手段：
• 如过遇到卡第一屏或者第二屏的时候，尝试不刷入开机动画进入
• 遇到无法下拉控制中心的时候，尝试核心破解后安装其他界面组件或者压缩包内的系统界面组件
• 如果界面组件无法下拉，自行删除MIUISystemUIPlugin.apk后重新刷入Magisk模块
• 如果遇到界面Monet取色异常的程序，尝试删除Overlay内叠加层后重新刷入模块
• 实在不会就加QQ群咨询:

- 莫奈的花园①群 516601187
- 莫奈的花园②群 731438978
- 莫奈的花园③群 179664825
- 莫奈的花园④群 820353204
- 莫奈的花园⑤群 697457720

酷安@MonetCarlos

✔ English
Preparations before flashing the module：
• Core Patch （5.0.4.4+）
• Magisk Automatic brick saving module
• TWRP

Repair method：
• If you encounter stuck on the first or second screen, try to enter without flashing the startup animation.
• When you are unable to pull down the control center, try to crack the core and install other interface components or system interface components in the compressed package.
• If the interface component cannot be pulled down, delete the MIUISystemUIPlugin.apk and reload the Magisk module.
• If you encounter a program with abnormal Monet color selection on the interface, try deleting the overlay in the Overlay and reloading the module.
• I really don’t know how to consult about adding a TG channel:

- Monet's Resource Center：
https://t.me/monetcarlos
https://t.me/monetcarlosfaq
- HyperOS System interface component exchange group
https://t.me/MIUI1230
- EGLIFE
https://t.me/EGLife2023

Coolapk@MonetCarlos